package com.kitri.dao;

import java.sql.*;
import java.util.List;

import com.kitri.dto.Customer;
import com.kitri.exception.NotFoundException;

public class CustomerDao {

	public Customer selectById(String id) throws com.kitri.exception.NotFoundException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		//1)JDBC드라이버 로드
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//2)DB연결
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:orcl", "kitri", "kitri");
			//3)
			String selectByIdSQL="SELECT * FROM customer WHERE id=?";
			pstmt = con.prepareStatement(selectByIdSQL);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				Customer c = new Customer();
				c.setId(id);
				c.setPass(rs.getString("pass"));
				c.setId(rs.getString("name"));
				return c;
			} else {
				throw new NotFoundException("아이디에 해당하는 고객이 없습니다.");
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new NotFoundException(e.getMessage());
		} catch (SQLException e) {
			e.printStackTrace();
			throw new NotFoundException(e.getMessage());
		} finally {
			try {
				if(rs != null)
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(pstmt != null)
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(con != null)
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	
	public List<Customer> selectByName(String name){
		return null;
	}
	
	public List<Customer> selectAll(){
		return null;
	}
	
	public void insert(Customer c) {
		
	}
}

package com.kitri.admin.model.dao;

public interface AdminDao {

}

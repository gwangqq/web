package com.kitri.admin.model.service;

public interface AdminService {

}

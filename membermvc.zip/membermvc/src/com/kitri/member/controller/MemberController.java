package com.kitri.member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kitri.member.model.MemberDetailDto;
import com.kitri.member.model.service.MemberServiceImpl;
import com.kitri.util.SiteConstance;

@WebServlet("/user")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
			String act = request.getParameter("act");
//			if(act.equals("mvjoin"){ mvjoin이 null일 때를 고려하지 못해서 null-point-exception이 발생한다
			if("mvjoin".equals(act)) {
				response.sendRedirect("/membermvc/user/member/member.jsp");
				
			} else if ("mvlogin".equals(act)) {
				response.sendRedirect("/membermvc/user/login/login.jsp");
				
			} else if ("idcheck".equals(act)) {
				String sid = request.getParameter("sid");
				String resultXML = MemberServiceImpl.getMemberSerivce().idCheck(sid);
				
				response.setContentType("text/xml;charset=UTF-8"); //text 형식으로 받지만 xml형식으로 내보낸다
				PrintWriter out = response.getWriter();
				out.print(resultXML);
				
			} else if ("zipsearch".equals(act)) {
				String doro = request.getParameter("doro");
//				System.out.println(doro);
				String resultXML = MemberServiceImpl.getMemberSerivce().zipSearch(doro);
//				System.out.println(resultXML);
				response.setContentType("text/xml;charset=UTF-8"); //text 형식으로 받지만 xml형식으로 내보낸다
				PrintWriter out = response.getWriter();
				out.print(resultXML);
			} else if ("register".equals(act)) {
				MemberDetailDto memberdetailDto = new MemberDetailDto();
				memberdetailDto.setName(request.getParameter("name"));
				memberdetailDto.setId(request.getParameter("id"));
				memberdetailDto.setPass(request.getParameter("pass"));
				memberdetailDto.setEmailid(request.getParameter("emailid"));
				memberdetailDto.setEmaildomain(request.getParameter("emaildomain"));
				memberdetailDto.setTel1(request.getParameter("tel1"));
				memberdetailDto.setTel2(request.getParameter("tel2"));
				memberdetailDto.setTel3(request.getParameter("tel3"));
				memberdetailDto.setZipcode(request.getParameter("zipcode"));
				memberdetailDto.setAddress(request.getParameter("address"));
				memberdetailDto.setAddressdetail(request.getParameter("address_detail"));
				
				int cnt = MemberServiceImpl.getMemberSerivce().registerMember(memberdetailDto);
				
			} else if ("".equals(act)) {
				
			} else if ("".equals(act)) {
				
			}
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding(SiteConstance.ENCODE);
		doGet(request, response);
	}

}

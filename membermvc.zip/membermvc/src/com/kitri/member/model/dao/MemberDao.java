package com.kitri.member.model.dao;

import java.util.List;
import java.util.Map;

import com.kitri.member.model.MemberDetailDto;
import com.kitri.member.model.ZipcodeDto;

public interface MemberDao {
	
//	id 중복 검사.....
	int idCheck(String id);		
//	시, 군 , 구, zipcodeDto가 들어간 List
	List<ZipcodeDto> zipSearch(String doro);
//	
	int registerMember(MemberDetailDto memberdetailDto);
//	memberDto
	MemberDetailDto loginMember(Map<String, String> map);
	
	
//	회원 수정 눌렀을 때 정보 싹 나오는 기능
    MemberDetailDto getMember(String id);
//	회원 수정 하고나서 완료
	int modifyMember(MemberDetailDto memberdetailDto);//0: 참 | 1: 거짓
//	회원 id 가져와서 int로 반환해야함
	int deleteMember(String id);//0: 참 | 1: 거짓
}

package com.kitri.member.model;

public class ZipcodeDto {
	private String zipcode;
	private String sido;
	private String gugun;
	private String upmyon;
	private String doro;
	private String buildingNumber;
	private String sigugunBuildingName;

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getSido() {
		return sido;
	}

	public void setSido(String sido) {
		this.sido = sido;
	}

	public String getGugun() {
		return gugun;
	}

	public void setGugun(String gugun) {
		this.gugun = gugun;
	}

	public String getUpmyon() {
		return upmyon;
	}

	public void setUpmyon(String upmyon) {
		this.upmyon = upmyon;
	}

	public String getDoro() {
		return doro;
	}

	public void setDoro(String doro) {
		this.doro = doro;
	}

	public String getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getSigugunBuildingName() {
		return sigugunBuildingName;
	}

	public void setSigugunBuildingName(String sigugunBuildingName) {
		this.sigugunBuildingName = sigugunBuildingName;
	}

}

package com.kitri.basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/counter")
public class Counter extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	int cnt;
//	int totalLen;
	public void init() {
		cnt = 0;
//		totalLen=8;
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		cnt++;
//		String cntStr= cnt + "";
//		int cntLen = cntStr.length(); 동적으로 자릿수를 증가시키기 위해서 고정값 8이 아닌 변수로 지정한 것!!
//		int zeroLen= totalLen - cntLen;
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("	<body>");
		out.println("당신은 ");
//
//		for(int i = 0; i<zeroLen;i++) {
//			out.println("<img src = \"/basicservlet/img/0.PNG\" width =\"50\">");
//		}
//		
//		for(int i = 0; i<totalLen;i++) {
//			out.println("<img src = \"/basicservlet/img/"+ str.charAt(i)+".PNG\" width =\"50\">");
//		}
//		
//
//		
		String str = Integer.toString(cnt);		
		int len = str.length();
		for(int i = 0; i < 8 - len; i++) {
			out.println("<img src = \"/basicservlet/img/0.PNG\" width =\"50\">");
		}
		for(int i = 0; i < len; i++) {
			out.println("<img src = \"/basicservlet/img/"+ str.charAt(i)+".PNG\" width =\"50\">");
		}
		out.println("번째 방문자입니다.");
		out.println("	</body>");
		out.println("</html>");
	}
}

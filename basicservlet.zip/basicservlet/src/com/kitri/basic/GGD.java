package com.kitri.basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ggd")
public class GGD extends HttpServlet {
	private static final long serialVersionUID = 1L;

	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("	<body>");
		out.println("<h2 align = \"center\">******************구구단******************</h2>");
		out.println("<table border = \"1\", width = \"800\", height= \"800\" align = \"center\">");
		out.println("	<tbody align = \"center\">");
		
		for (int i = 1; i <= 9; i++) {

			out.print("<tr>");
			for(int dan = 2; dan<=9; dan++) {
				String color = dan%2==0 ? "pink" : "lightblue";
				out.print("<td bgcolor = \""+ color +"\">" + dan + "*" +i+ "=" + i*dan + "</td>");
			}
			out.println("</tr>");
		}
		out.println("	</tbody>");
		out.println("	</table>");
		out.println("	</body>");
		out.println("</html>");
	}

}
